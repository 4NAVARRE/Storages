

#include <iostream>
#include <list>
#include <queue>
#include <map>

using namespace std;

bool asessment(int x)
{
    return x < 10;
}

void findFunction(map <string, int>::iterator iter, map <string, int> &storageMap)
{
    if (iter == storageMap.end())
    {
        cout << "Failed to find ellement" << endl;
    }
    else
    {
        cout << "Ellement to find: " << iter->first << ", " << iter->second << endl;
    }
}

int main()
{
    //list example

    list <int> storageList;

    list <int> storageListV2 = {21, 23, 25};

    storageList.push_back(1);
    storageList.push_back(3);
    storageList.push_back(5);
    storageList.push_back(7);
    storageList.push_back(9);
    storageList.push_back(3);
    storageList.push_back(3);
    storageList.push_back(3);
    storageList.push_back(3);

    //storageListV2.push_back(21);
    //storageListV2.push_back(23);
    //storageListV2.push_back(25);

    list<int> ::iterator it_; //create iterator

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    advance(it_, -3); //change iterator value

    storageList.insert(it_, 15);

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    advance(it_, -2);

    storageList.erase(it_); //delete ellements

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    storageList.unique();  //delte with same amount

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    storageList.pop_back(); //delete ellement from the end
    storageList.pop_front();  //delete ellement from the begining

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    storageList.sort();

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    storageList.merge(storageListV2); //connect two lists (require sorted list)

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    //while (!storageList.empty())   remove all the ellements
    //{
    //    storageList.pop_back();
    //}

    storageList.remove(3);  //remove certain ellement

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    storageList.remove_if(asessment);  //revove with condition

    cout << endl;

    for (it_ = storageList.begin(); it_ != storageList.end(); it_++)
    {
        cout << "ellement: " << *it_ << endl;
    }

    cout << endl;

    map <string, int> storageMap = {
        {"Alexey", 1},
        {"Jhon", 2},
        {"Andrew", 3},
        {"Lora", 4}
    };

    storageMap.insert(make_pair("Amy", 6));
    storageMap.insert(make_pair("Alex", 5));

    map <string, int>::iterator iter;

    for (iter = storageMap.begin(); iter != storageMap.end(); iter++)
    {
        cout << "Map Ellement: " << iter->first << ", " << iter->second << endl;
    }

    
    iter = storageMap.find("Anjelo");

    findFunction(iter, storageMap);

    queue <string> storageQueue;

    storageQueue.push("Anjelo");
    storageQueue.push("Antony");
    storageQueue.push("Andrew");

    while (!storageQueue.empty())
    {
        iter = storageMap.find(storageQueue.front());
        findFunction(iter, storageMap);
        storageQueue.pop();
    }



}

